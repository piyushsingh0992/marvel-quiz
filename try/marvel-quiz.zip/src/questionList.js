var questionArray = [
  { key: 1, question: " let's start the quiz", img: "./images/tony.jpg" },

  {
    key: 2,
    question: " Which Was The Third Stone Thanos Added To His Gauntlet?",
    ans: "power stone",
    img: "./images/antman.jpg "
  },

  {
    key: 3,
    question: "What is Captain America's shield made of?",
    ans: "sibranium",
    img: "./images/captain.jpg"
  },

  {
    key: 4,
    question:
      "What is the name of the axe created for and then used by Thor in Avengers: Infinity War?",
    ans: "stormbreaker",
    img: "./images/black-widow-2.jpg"
  },

  {
    key: 5,
    question:
      " What's the name of the mysterious blue glowing cube that Loki uses as a weapon?",
    ans: "tesseract",
    img: "./images/black-widow.jpg"
  },

  {
    key: 6,
    question: "On what planet was the Soul Stone hidden in Infinity War?",
    ans: "vormir",
    img: "./images/shield.jpg"
  },

  {
    key: 7,
    question: " How man Infinity Stones are there?",
    ans: "six",
    img: "./images/captain-marvel.jpg"
  },
  {
    key: 8,
    question: "In which film’s post-credit scene did Thanos first appear?",
    ans: "the avengers",
    img: "./images/hand.jpg"
  },

  {
    key: 9,
    question:
      " Which beloved comic book writer has cameoed in every Marvel film up to Avengers: Endgame?",
    ans: "stan lee",
    img: "./images/hawkeye.png"
  },

  {
    key: 10,
    question:
      "Unlike the comics, who created Ultron in Avengers: Age of Ultron?",
    ans: "iron Man",
    img: "./images/hulk-2.jpg"
  },

  {
    key: 11,
    question:
      "What is the name of the microscopic universe Ant-Man travels to when he goes sub-atomic?",
    ans: "quantum realm",
    img: "./images/hulk.jpg"
  },

  {
    key: 12,
    question: "What war did Captain America fight in?",
    ans: "world war 2",
    img: "./images/ironman.png"
  },

  {
    key: 13,
    question: "What is Thor’s hammer called?",
    ans: "mjolnir",
    img: "./images/tony.jpg"
  },

  {
    key: 14,
    question: "What turned Bruce Banner into the Hulk?",
    ans: "gamma radiation",
    img: "./images/spiderman.jpg"
  },

  {
    key: 15,
    question: "What was Tony’s suit’s AI called?",
    ans: "jarvis",
    img: "./images/ultron.jpg"
  },

  {
    key: 16,
    question: "What part of New York is Spider-Man from?",
    ans: "queens",
    img: "./images/thor-hammer.jpg"
  },

  {
    key: 17,
    question: "Whose logo appeared in the post-credits scene in Infinity War?",
    ans: "captain marvel",
    img: "./images/thor.jpg "
  },

  {
    key: 18,
    question: "Who is the Sorcerer Supreme?",
    ans: "doctor strange",
    img: "./images/thanos-x.png "
  }
];

export default questionArray;
